const utente = {
    nome: '',
    eta: 0,
    altezzaCm: 0,
    pesoKg: 0,

    calcolaIMC() {
        const h = this.altezzaCm / 100;
        return +(this.pesoKg / (h * h)).toFixed(1);
    },

    categoriaIMC() {
        const imc = this.calcolaIMC();
        if (imc < 18.5) return 'Sottopeso';
        if (imc < 25)   return 'Normopeso';
        if (imc < 30)   return 'Sovrappeso';
        return 'Obeso';
    }
};

/* ---------- DATI PERSISTENTI ---------- */
const storicoIMC = [];
const listaAttivita = [];

/* ---------- TIMER ---------- */
let timerInterval = null;
let secondiRimanenti = 0;

/* ---------- RIFERIMENTI DOM ---------- */
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

// IMC
const formIMC          = $('#form-imc');
const inputNome        = $('#nome');
const inputEta         = $('#eta');
const inputAltezza     = $('#altezza');
const inputPeso        = $('#peso');
const errNome          = $('#err-nome');
const errEta           = $('#err-eta');
const errAltezza       = $('#err-altezza');
const errPeso          = $('#err-peso');
const risultatoBoxIMC  = $('#risultato-imc');

// BMR
const formBMR          = $('#form-bmr');
const inputEtaBMR      = $('#eta-bmr');
const inputAltezzaBMR  = $('#altezza-bmr');
const inputPesoBMR     = $('#peso-bmr');
const selectAttivita   = $('#livello-attivita');
const errEtaBMR        = $('#err-eta-bmr');
const errAltezzaBMR    = $('#err-altezza-bmr');
const errPesoBMR       = $('#err-peso-bmr');
const risultatoBoxBMR  = $('#risultato-bmr');

// Diario
const inputAttivita    = $('#input-attivita');
const btnAggiungi      = $('#btn-aggiungi');
const listaAttivitaDOM = $('#lista-attivita');
const msgAttivita      = $('#messaggio-attivita');

// Timer
const inputMinuti      = $('#input-minuti');
const btnAvviaTimer    = $('#btn-avvia-timer');
const btnFermaTimer    = $('#btn-ferma-timer');
const displayTimer     = $('#display-timer');
const msgTimer         = $('#messaggio-timer');

// Storico
const listaStorico     = $('#lista-storico');
const btnPulisciStorico = $('#btn-pulisci-storico');
const contatoreMisurazioni = $('#contatore-misurazioni');
const contatoreStorico = $('#contatore-storico');

// Tema
const btnTema = $('#btnTema');

/* ---------- FETCH CONSIGLI PERSONALIZZATI (ASYNC/AWAIT) ---------- */
async function caricaConsigliBenessere(categoria, eta) {
    try {
        await new Promise(resolve => setTimeout(resolve, 800));

        const consigli = {
            'Sottopeso': {
                titolo: 'Aumenta l\'apporto calorico',
                testo: 'Consuma più proteine e calorie. Fai 3 pasti principali + 2 snack. Sollevamento pesi 3x/settimana.',
                emoji: '',
                esercizio: 'Sollevamento pesi (30 min, 3x/settimana)'
            },
            'Normopeso': {
                titolo: ' Mantieni il tuo stile di vita',
                testo: 'Perfetto! Continua così. Esercizio regolare 3-4x/settimana e dieta equilibrata.',
                emoji: '',
                esercizio: 'Cardio + Forza (45 min, 3-4x/settimana)'
            },
            'Sovrappeso': {
                titolo: 'Inizia un deficit calorico lieve',
                testo: 'Riduci 300-500 kcal al giorno. Aumenta attività fisica. Dormi 7-8 ore.',
                emoji: '',
                esercizio: 'Cardio moderato (30-45 min, 4-5x/settimana)'
            },
            'Obeso': {
                titolo: 'Consulta un professionista',
                testo: 'Parla con medico o nutrizionista. Inizia gradualmente: camminate di 30 min/giorno.',
                emoji: '',
                esercizio: 'Camminata (30 min, 5x/settimana)'
            }
        };

        const consiglio = consigli[categoria];
        console.log('✅ Consigli caricati:', consiglio);
        return consiglio;

    } catch (errore) {
        console.error(' Errore nel caricamento consigli:', errore);
        return {
            titolo: 'Errore',
            testo: 'Non è stato possibile caricare i consigli. Riprova.',
            emoji: '',
            esercizio: 'Nessuno'
        };
    }
}

/* ---------- VALIDAZIONE IMC (REGEX) ---------- */
function validaFormIMC() {
    let ok = true;
    const nomeVal = inputNome.value.trim();

    if (!/^[A-Za-zÀ-ù]{1}[a-zà-ù\s]{1,}$/.test(nomeVal)) {
        errNome.textContent = 'Nome: prima lettera maiuscola, solo lettere e spazi.';
        ok = false;
    } else errNome.textContent = '';

    const etaVal = parseInt(inputEta.value, 10);
    if (isNaN(etaVal) || etaVal < 1 || etaVal > 120) {
        errEta.textContent = 'Età: inserire un numero tra 1 e 120.';
        ok = false;
    } else errEta.textContent = '';

    const altVal = parseFloat(inputAltezza.value);
    if (isNaN(altVal) || altVal < 50 || altVal > 250) {
        errAltezza.textContent = 'Altezza: tra 50 e 250 cm.';
        ok = false;
    } else errAltezza.textContent = '';

    const pesoVal = parseFloat(inputPeso.value);
    if (isNaN(pesoVal) || pesoVal < 20 || pesoVal > 300) {
        errPeso.textContent = 'Peso: tra 20 e 300 kg.';
        ok = false;
    } else errPeso.textContent = '';

    return ok;
}

/* ---------- SUBMIT FORM IMC (CON ASYNC/AWAIT) ---------- */
formIMC.addEventListener('submit', async function(e) {
    e.preventDefault();
    if (!validaFormIMC()) return;

    utente.nome      = inputNome.value.trim();
    utente.eta       = parseInt(inputEta.value, 10);
    utente.altezzaCm = parseFloat(inputAltezza.value);
    utente.pesoKg    = parseFloat(inputPeso.value);

    const imc       = utente.calcolaIMC();
    const categoria = utente.categoriaIMC();

    risultatoBoxIMC.innerHTML = `
        <p>Ciao <strong>${utente.nome}</strong> (${utente.eta} anni)</p>
        <p>Il tuo <strong>IMC è ${imc}</strong> – Categoria: <strong>${categoria}</strong></p>
        <div style="margin-top: 1.2rem; text-align: center; color: var(--accent);">
            <p>Caricamento consigli personalizzati...</p>
        </div>
    `;

    const consiglio = await caricaConsigliBenessere(categoria, utente.eta);

    risultatoBoxIMC.innerHTML = `
        <p>Ciao <strong>${utente.nome}</strong> (${utente.eta} anni)</p>
        <p>Il tuo <strong>IMC è ${imc}</strong> – Categoria: <strong>${categoria}</strong></p>

        <div style="margin-top: 1.5rem; padding: 1.5rem; background: linear-gradient(135deg, var(--bg-accent-light) 0%, rgba(255,109,41,0.04) 100%);
                    border-radius: 12px; border-left: 5px solid var(--accent); animation: slideIn 0.4s ease-out;">
            <h3 style="color: var(--accent); margin-bottom: 0.8rem; font-size: 1.2rem;">
                ${consiglio.emoji} ${consiglio.titolo}
            </h3>
            <p style="color: var(--text-primary); margin-bottom: 1rem; line-height: 1.6;">
                ${consiglio.testo}
            </p>
            <div style="background: rgba(255,255,255,0.5); padding: 1rem; border-radius: 8px;
                        border-top: 3px solid var(--accent);">
                <p style="color: var(--text-primary); font-weight: 600; margin-bottom: 0.3rem;">
                     Esercizio consigliato:
                </p>
                <p style="color: var(--text-secondary); font-size: 0.95rem;">
                    ${consiglio.esercizio}
                </p>
            </div>
        </div>
    `;

    storicoIMC.push({
        nome: utente.nome,
        eta: utente.eta,
        altezza: utente.altezzaCm,
        peso: utente.pesoKg,
        imc,
        categoria,
        data: new Date().toLocaleDateString('it-IT')
    });

    aggiornaStorico();
    aggiornaContatori();
    aggiornaAchievements();
    aggiornaAnalytics();
});

/* ---------- VALIDAZIONE BMR ---------- */
function validaFormBMR() {
    let ok = true;
    const etaVal = parseInt(inputEtaBMR.value, 10);
    if (isNaN(etaVal) || etaVal < 1 || etaVal > 120) {
        errEtaBMR.textContent = 'Età: 1-120 anni.';
        ok = false;
    } else errEtaBMR.textContent = '';

    const altVal = parseFloat(inputAltezzaBMR.value);
    if (isNaN(altVal) || altVal < 50 || altVal > 250) {
        errAltezzaBMR.textContent = 'Altezza: 50-250 cm.';
        ok = false;
    } else errAltezzaBMR.textContent = '';

    const pesoVal = parseFloat(inputPesoBMR.value);
    if (isNaN(pesoVal) || pesoVal < 20 || pesoVal > 300) {
        errPesoBMR.textContent = 'Peso: 20-300 kg.';
        ok = false;
    } else errPesoBMR.textContent = '';

    return ok;
}

/* ---------- CALCOLO BMR (Harris-Benedict) ---------- */
function calcolaBMR(peso, altezza, eta, sesso) {
    if (sesso === 'uomo') {
        return 88.362 + (13.397 * peso) + (4.799 * altezza) - (5.677 * eta);
    } else {
        return 447.593 + (9.247 * peso) + (3.098 * altezza) - (4.330 * eta);
    }
}

/* ---------- SUBMIT FORM BMR ---------- */
formBMR.addEventListener('submit', function(e) {
    e.preventDefault();
    if (!validaFormBMR()) return;

    const eta     = parseInt(inputEtaBMR.value, 10);
    const altezza = parseFloat(inputAltezzaBMR.value);
    const peso    = parseFloat(inputPesoBMR.value);
    const sesso   = document.querySelector('input[name="sesso"]:checked').value;
    const fattore = parseFloat(selectAttivita.value);

    const bmr  = Math.round(calcolaBMR(peso, altezza, eta, sesso));
    const tdee = Math.round(bmr * fattore);

    risultatoBoxBMR.innerHTML = `
        <p><strong>Metabolismo basale (BMR):</strong> ${bmr} kcal/giorno</p>
        <p><strong>Fabbisogno calorico totale (TDEE):</strong> ${tdee} kcal/giorno</p>
        <p style="font-size:0.85rem; color: var(--text-secondary);">*Formula di Harris-Benedict</p>
    `;
});

/* ---------- STORICO ---------- */
function aggiornaStorico() {
    listaStorico.innerHTML = '';
    storicoIMC.forEach((m) => {
        const li = document.createElement('li');
        li.textContent = `${m.data} – ${m.nome}: IMC ${m.imc} (${m.categoria}) – ${m.altezza}cm / ${m.peso}kg`;
        listaStorico.appendChild(li);
    });
    contatoreStorico.textContent = `${storicoIMC.length} misurazioni salvate`;
}

btnPulisciStorico.addEventListener('click', () => {
    storicoIMC.length = 0;
    aggiornaStorico();
    aggiornaContatori();
});

function aggiornaContatori() {
    contatoreMisurazioni.textContent = storicoIMC.length;
    contatoreStorico.textContent = `${storicoIMC.length} misurazioni salvate`;
}

/* ---------- DIARIO ATTIVITÀ ---------- */
btnAggiungi.addEventListener('click', () => {
    const testo = inputAttivita.value.trim();
    if (!testo) {
        msgAttivita.textContent = 'Inserisci una descrizione per l\'attività.';
        return;
    }
    msgAttivita.textContent = '';
    listaAttivita.push(testo);
    inputAttivita.value = '';
    aggiornaListaAttivita();
});

function aggiornaListaAttivita() {
    listaAttivitaDOM.innerHTML = '';
    listaAttivita.forEach((att, i) => {
        const li = document.createElement('li');
        li.innerHTML = `${att} <span class="rimuovi" data-i="${i}">✕</span>`;
        listaAttivitaDOM.appendChild(li);
    });
    $$('#lista-attivita .rimuovi').forEach(span => {
        span.addEventListener('click', function() {
            const idx = +this.dataset.i;
            listaAttivita.splice(idx, 1);
            aggiornaListaAttivita();
        });
    });
}

/* ---------- TIMER ---------- */
function formattaTempo(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

btnAvviaTimer.addEventListener('click', () => {
    const min = parseInt(inputMinuti.value, 10);
    if (isNaN(min) || min < 1 || min > 60) {
        msgTimer.textContent = 'Inserisci un valore valido (1–60 minuti).';
        return;
    }
    msgTimer.textContent = '';
    if (timerInterval) clearInterval(timerInterval);

    timerUsageCount++;
    aggiornaAchievements();

    secondiRimanenti = min * 60;
    displayTimer.textContent = formattaTempo(secondiRimanenti);

    timerInterval = setInterval(() => {
        secondiRimanenti--;
        displayTimer.textContent = formattaTempo(secondiRimanenti);
        if (secondiRimanenti <= 0) {
            clearInterval(timerInterval);
            timerInterval = null;
            msgTimer.textContent = ' Tempo scaduto! Ottimo lavoro. ';
            displayTimer.textContent = '00:00';
        }
    }, 1000);
});

btnFermaTimer.addEventListener('click', () => {
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
        msgTimer.textContent = 'Timer fermato.';
    }
});

/* ---------- TEMA GIORNO/NOTTE ---------- */
function applicaTemaOrario() {
    const ora = new Date().getHours();
    document.body.classList.toggle('tema-scuro', ora < 6 || ora >= 18);
}

btnTema.addEventListener('click', () => {
    document.body.classList.toggle('tema-scuro');
});

/* ---------- EVENTI MOUSE SULLE CARD ---------- */
$$('.card').forEach(card => {
    card.addEventListener('mouseover', function() {
        this.style.borderColor = 'var(--accent)';
    });
    card.addEventListener('mouseout', function() {
        this.style.borderColor = '';
    });
});

/* ---------- ANIMAZIONE CONTATORI ALLO SCROLL ---------- */
function animaContatori() {
    $$('.stat-number[data-target]').forEach(el => {
        const target = +el.dataset.target;
        if (el.textContent === '0' || el.dataset.animato) return;
        el.dataset.animato = '1';
        let current = 0;
        const step = Math.ceil(target / 40);
        const interval = setInterval(() => {
            current += step;
            if (current >= target) {
                el.textContent = target;
                clearInterval(interval);
            } else {
                el.textContent = current;
            }
        }, 30);
    });
}

window.addEventListener('scroll', animaContatori, { once: false });

/* ========== SISTEMA DI ACHIEVEMENT E PUNTI ========== */
const achievements = {
    'primo-calcolo': { unlocked: false, punti: 50 },
    '5-misurazioni': { unlocked: false, punti: 100 },
    'attivita-giornaliera': { unlocked: false, punti: 75 },
    'timer-master': { unlocked: false, punti: 150 }
};

let puntiBenessere = 0;
let timerUsageCount = 0;

function aggiornaAchievements() {
    if (storicoIMC.length > 0 && !achievements['primo-calcolo'].unlocked) {
        sbloccaAchievement('primo-calcolo');
    }

    if (storicoIMC.length >= 5 && !achievements['5-misurazioni'].unlocked) {
        sbloccaAchievement('5-misurazioni');
    }

    if (listaAttivita.length > 0 && !achievements['attivita-giornaliera'].unlocked) {
        sbloccaAchievement('attivita-giornaliera');
    }

    if (timerUsageCount >= 10 && !achievements['timer-master'].unlocked) {
        sbloccaAchievement('timer-master');
    }
}

function sbloccaAchievement(id) {
    achievements[id].unlocked = true;
    puntiBenessere += achievements[id].punti;

    const badge = document.querySelector(`[data-achievement="${id}"]`);
    if (badge) {
        badge.classList.add('sbloccato');
        badge.classList.remove('bloccato');
        badge.querySelector('.badge-status').style.display = 'inline-block';
    }

    aggiornaPunti();
}

function aggiornaPunti() {
    document.getElementById('punti-totali').textContent = puntiBenessere;
}

/* ========== ARTICOLI EDUCATIVI ========== */
const articoli = {
    nutrizione: [
        {
            titolo: 'Alimentazione Consapevole',
            testo: 'Una corretta nutrizione è la base del benessere. Scegli alimenti integrali, verdure stagionali e proteine magre. Evita cibi processati e zuccheri aggiunti. L\'alimentazione consapevole significa ascoltare il tuo corpo e le sue necessità.'
        },
        {
            titolo: 'L\'Importanza dell\'Idratazione',
            testo: 'L\'acqua è essenziale per il 60% del nostro corpo. Bevi almeno 2 litri di acqua al giorno per mantenere idratazione ottimale. L\'acqua migliora il metabolismo, la concentrazione e la salute della pelle.'
        },
        {
            titolo: ' Grassi Salutari',
            testo: 'Non tutti i grassi sono nemici! Acidi grassi omega-3 (pesce, noci), avocado e olio d\'oliva sono fondamentali per la salute cardiaca e cerebrale. Consuma con moderazione ma con consapevolezza.'
        }
    ],
    esercizio: [
        {
            titolo: 'Iniziare una Routine Fitness',
            testo: 'Non è mai tardi per iniziare! Comincia con 30 minuti di movimento 3 volte a settimana. Combina cardio e sollevamento pesi per risultati ottimali. La costanza è più importante dell\'intensità.'
        },
        {
            titolo: ' Esercizio Aerobico e Anarobico',
            testo: 'Cardio (corsa, nuoto) migliora la resistenza; sollevamento pesi aumenta massa muscolare. Combina entrambi per una salute completa. Varia gli esercizi per evitare plateau.'
        },
        {
            titolo: 'Lo Stretching e la Flessibilità',
            testo: 'Dedicare 10-15 minuti al giorno allo stretching riduce dolori muscolari e migliora la mobilità. Una buona flessibilità previene infortuni e migliora la qualità della vita.'
        }
    ],
    'salute-mentale': [
        {
            titolo: ' Meditazione e Consapevolezza',
            testo: 'La meditazione riduce stress e ansia. Anche 5-10 minuti al giorno di consapevolezza migliora il benessere mentale. Apps come Headspace o Calm possono guidarti nel percorso.'
        },
        {
            titolo: ' Il Sonno, il Pilastro del Benessere',
            testo: 'Dormi 7-9 ore per notte. Un sonno regolare regola ormoni, migliora memoria e rafforza il sistema immunitario. Evita schermi 1 ora prima di dormire.'
        },
        {
            titolo: ' L\'Importanza della Comunicazione',
            testo: 'Condividere i tuoi sentimenti con amici, famiglia o professionisti è fondamentale. Non rimanere solo con i tuoi problemi. La comunità e il supporto sociale sono pilastri della salute mentale.'
        }
    ],
    prevenzione: [
        {
            titolo: ' Check-up Regolari',
            testo: 'Effettua visite mediche periodiche anche se stai bene. La prevenzione è meglio che curare. Monitora pressione, colesterolo e altri parametri vitali.'
        },
        {
            titolo: ' Prevenzione dalle Malattie',
            testo: 'Vaccini, igiene personale e stili di vita sani sono le migliori difese. Lava le mani frequentemente, mantieni un peso salutare e evita fumo/alcol in eccesso.'
        },
        {
            titolo: 'Educazione Sanitaria',
            testo: 'Conosci il tuo corpo. Impara a riconoscere i segnali di allarme. L\'educazione è il primo strumento per proteggere la tua salute e quella della comunità.'
        }
    ]
};

function caricaArticoli(categoria = 'nutrizione') {
    const container = document.getElementById('articles-container');
    const articoliCategoria = articoli[categoria] || [];

    container.innerHTML = articoliCategoria.map(art => `
        <div class="articolo-card">
            <h4>${art.titolo}</h4>
            <p>${art.testo}</p>
        </div>
    `).join('');
}

$$('.btn-filtro').forEach(btn => {
    btn.addEventListener('click', function() {
        $$('.btn-filtro').forEach(b => b.classList.remove('attivo'));
        this.classList.add('attivo');
        caricaArticoli(this.dataset.categoria);
    });
});

/* ========== ANALYTICS & STATISTICHE ========== */
function aggiornaAnalytics() {
    const container = document.getElementById('analytics-container');

    if (storicoIMC.length === 0) {
        container.innerHTML = '<p style="color: var(--text-secondary); text-align: center;">Inserisci almeno una misurazione per visualizzare le statistiche</p>';
        return;
    }

    const imc_values = storicoIMC.map(m => m.imc);
    const media_imc = (imc_values.reduce((a, b) => a + b, 0) / imc_values.length).toFixed(1);
    const min_imc = Math.min(...imc_values).toFixed(1);
    const max_imc = Math.max(...imc_values).toFixed(1);

    const categorie = storicoIMC.map(m => m.categoria);
    const categoriaAttuale = categorie[categorie.length - 1];

    const variazionePeso = storicoIMC.length > 1
        ? (storicoIMC[storicoIMC.length - 1].peso - storicoIMC[0].peso).toFixed(1)
        : 0;

    let profiloTesto = '';
    if (variazionePeso < 0) {
        profiloTesto = ' Sei sulla giusta strada! Stai perdendo peso in modo salutare.';
    } else if (variazionePeso > 0) {
        profiloTesto = ' Potresti aumentare l\'attività fisica per mantenere il tuo peso.';
    } else {
        profiloTesto = ' Il tuo peso è stabile. Continua così!';
    }

    container.innerHTML = `
        <div class="analytics-grid">
            <div class="analytics-stat">
                <h4>IMC Medio</h4>
                <p>${media_imc}</p>
            </div>
            <div class="analytics-stat">
                <h4>⬇IMC Minimo</h4>
                <p>${min_imc}</p>
            </div>
            <div class="analytics-stat">
                <h4>⬆IMC Massimo</h4>
                <p>${max_imc}</p>
            </div>
            <div class="analytics-stat">
                <h4>Variazione Peso</h4>
                <p>${variazionePeso > 0 ? '+' : ''}${variazionePeso} kg</p>
            </div>
        </div>

        <div style="margin-top: 2rem; padding: 1.5rem; background: linear-gradient(135deg, var(--bg-accent-light) 0%, rgba(255,109,41,0.04) 100%);
                    border-radius: 12px; border-left: 5px solid var(--accent);">
            <h4 style="color: var(--accent); margin-bottom: 0.8rem;">Il Tuo Profilo Attuale</h4>
            <p style="color: var(--text-primary); margin-bottom: 1rem;">${profiloTesto}</p>
            <p style="color: var(--text-secondary); font-size: 0.95rem;">Categoria: <strong>${categoriaAttuale}</strong> | Misurazioni: <strong>${storicoIMC.length}</strong></p>
        </div>
    `;
}

/* ---------- INIZIALIZZAZIONE ---------- */
window.addEventListener('DOMContentLoaded', () => {
    applicaTemaOrario();
    aggiornaContatori();
    animaContatori();
    caricaArticoli('nutrizione');
    aggiornaAchievements();
    aggiornaAnalytics();
});