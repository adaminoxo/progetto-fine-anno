# 🌿 Benessere Attivo

**Educazione alla Salute e al Benessere Psico-Fisico**

> Un'applicazione web interattiva per promuovere consapevolezza, educazione e monitoraggio della salute personale attraverso strumenti digitali accessibili e valuori di responsabilità civica.

---

## 📋 Indice

- [Descrizione](#descrizione)
- [Caratteristiche Principali](#caratteristiche-principali)
- [Tecnologie](#tecnologie)
- [Installazione](#installazione)
- [Come Usare](#come-usare)
- [Struttura del Progetto](#struttura-del-progetto)
- [Valore Civico e Sociale](#valore-civico-e-sociale)
- [Specifiche Tecniche](#specifiche-tecniche)
- [Screenshots](#screenshots)
- [Credits](#credits)

---

## 📖 Descrizione

**Benessere Attivo** è un sito web lato client che promuove l'**educazione alla salute e al benessere** attraverso:

- 🧮 **Calcoli personalizzati** (IMC, BMR, TDEE)
- 📚 **12+ Articoli educativi** su nutrizione, esercizio, salute mentale e prevenzione
- 📊 **Analytics intelligente** che traccia il tuo profilo di benessere
- 🏆 **Sistema di gamification** con achievement e punti benessere
- 📋 **Trello board** per gestire i tuoi obiettivi personali
- 🌙 **Dark/Light theme** per il comfort visivo
- 📱 **Responsive design** per mobile, tablet e desktop

**Missione:** Educare comunità sulla consapevolezza della salute, promuovendo responsabilità personale e solidarietà verso il benessere collettivo.

---

## ✨ Caratteristiche Principali

### 🧮 **Calcolatori di Salute**
- **Calcolo IMC** con validazione regex e categorizzazione (Sottopeso/Normopeso/Sovrappeso/Obeso)
- **Calcolo BMR** (Metabolismo Basale) con formula Harris-Benedict
- **Calcolo TDEE** (Fabbisogno Calorico) basato su attività fisica
- **Consigli personalizzati** con async/await

### 📊 **Analytics & Statistiche**
- Tracciamento IMC medio, minimo, massimo nel tempo
- Monitoraggio variazione peso
- Profilo personalizzato intelligente basato su trend
- Raccomandazioni adattive

### 📚 **Educazione al Benessere**
4 categorie con articoli approfonditi:
- 🥗 **Nutrizione** - Alimentazione consapevole, grassi salutari, idratazione
- 💪 **Esercizio** - Routine fitness, aerobico/anaerobico, stretching
- 🧠 **Salute Mentale** - Meditazione, sonno, comunicazione
- 🛡️ **Prevenzione** - Check-up, vaccinazioni, educazione sanitaria

### 🎮 **Sistema Gamification**
- 🏆 **4 Badge Achievement:**
  - Primo Passo (primo IMC)
  - Trend Watcher (5 misurazioni)
  - Ogni Giorno (attività registrata)
  - Timer Master (10 usi)
- 💯 **Punti Benessere** accumulati per motivare l'utente

### 📋 **Gestione Obiettivi**
- Board Trello interattiva con 3 colonne:
  - 📌 **Da Fare**
  - ⏳ **In Corso**
  - ✅ **Completato**
- Spostamento fluido tra colonne
- +30 punti per obiettivo completato

### 📅 **Diario Attività**
- Registra sessioni di allenamento
- Visualizza storico con timestamp
- Rimuovi attività non valide

### ⏱️ **Timer Esercizi**
- Timer con conto alla rovescia MM:SS
- Supporta 1-60 minuti
- Notifica al termine
- Traccia utilizzi per achievement

### 🌙 **Tema Scuro/Chiaro**
- Toggle automatico in base all'ora del giorno
- Personalizzabile manualmente
- Transizioni smooth

---

## 🛠️ Tecnologie

### **Frontend Stack**
- **HTML5** - Semantic markup
- **CSS3** - Gradient, animazioni, flexbox, grid
- **JavaScript (ES6+)** - Async/await, arrow functions, destructuring

### **Librerie/Strumenti**
- **CSS Variables** - Gestione temi dinamici
- **Regex** - Validazione form avanzata
- **localStorage** - Persistenza dati client-side
- **Unsplash API** - Immagini di qualità

### **Non utilizzate (su richiesta)**
- Framework (React, Vue, Angular)
- Build tools (Webpack, Vite)
- Dipendenze npm (vanilla JS)


## 🎯 Come Usare

### **1. Calcola il tuo IMC**
1. Scorri fino a **"Calcola il tuo IMC"**
2. Inserisci: Nome, Età, Altezza (cm), Peso (kg)
3. Clicca **"Calcola IMC"**
4. Ricevi categoria e consigli personalizzati

### **2. Calcola Fabbisogno Calorico**
1. Vai a **"Calcola il tuo fabbisogno calorico"**
2. Inserisci: Età, Sesso, Altezza, Peso, Livello attività
3. Clicca **"Calcola fabbisogno"**
4. Visualizza BMR e TDEE

### **3. Registra Attività**
1. Scorri a **"Diario attività fisica"**
2. Scrivi attività (es. "Corsa 30 min - 5 km")
3. Clicca **"Aggiungi"**
4. Rimuovi con ✕ se sbagli

### **4. Usa il Timer**
1. Vai a **"Timer per esercizi"**
2. Imposta minuti (1-60)
3. Clicca **"▶ Avvia"**
4. Ricevi notifica al termine

### **5. Scopri Articoli Educativi**
1. Scorri a **"📚 Impara il Benessere"**
2. Clicca categoria: Nutrizione, Esercizio, Salute Mentale, Prevenzione
3. Leggi articoli approfonditi

### **6. Monitora Statistiche**
1. Vai a **"📊 Il tuo Profilo Benessere"**
2. Visualizza: IMC medio/min/max
3. Leggi profilo personalizzato
4. Ricevi consigli adattivi

### **7. Gestisci Obiettivi**
1. Scorri a **"📋 I miei Obiettivi Benessere"**
2. Scrivi obiettivo (es. "Correre 5 km")
3. Clicca **"➕ Aggiungi"**
4. Sposta tra colonne: ▶ (In Corso), ✅ (Completato)
5. Guadagna +30 punti al completamento

### **8. Sblocca Achievement**
1. Vai a **"🏆 I tuoi Achievement"**
2. Raggiungi badge:
   - 🎯 Primo Passo (calcola IMC)
   - 📈 Trend Watcher (5 misurazioni)
   - ⚡ Ogni Giorno (registra attività)
   - ⏱️ Timer Master (10 usi timer)
3. Accumula **Punti Benessere**

### **9. Cambia Tema**
- Clicca 🌓 in alto a destra per toggle dark/light mode
- Si applica automaticamente di notte (18:00-6:00)

---

## 📁 Struttura del Progetto

```
v2/
├── index.html          # 307 linee - Markup semantico
├── style.css           # 1075 linee - Styling + Animazioni
├── script.js           # 617 linee - Logica JavaScript
└── README.md           # Questo file
```

### **index.html - Sezioni**
- Navbar con links e theme toggle
- Hero section con CTA
- Stats bar (contatori animati)
- IMC Calculator (form + risultati)
- BMR/TDEE Calculator
- Diario Attività
- Timer Esercizi
- Obiettivi Trello Board
- Storico Misurazioni
- Analytics Dashboard
- Sezione Impara (articoli filtrabili)
- Achievement System
- Footer informativo

### **script.js - Funzioni Principali**
```javascript
// Calcoli
calcolaIMC()           // Formula IMC
calcolaBMR()           // Formula Harris-Benedict
caricaConsigliBenessere() // Async/await

// Analytics
aggiornaAnalytics()    // Statistiche intelligenti

// Educazione
caricaArticoli()       // Filter articoli

// Gamification
sbloccaAchievement()   // Sistema badge
aggiornaPunti()        // Tracking punti

// Obiettivi
spostaObiettivo()      // Trello board
renderizzoTrelloBoard() // Rendering dinamico

// UI
applicaTemaOrario()    // Dark/light theme
animaContatori()       // Animazione statistiche
```

### **style.css - Sezioni Principali**
```css
:root                  /* CSS Variables */
@keyframes             /* Animazioni */
.navbar                /* Navigazione */
.hero                  /* Hero section */
.stats-bar             /* Statistiche */
.card                  /* Card design */
.form-row              /* Form layout */
.btn-primary/outline   /* Bottoni */
.trello-board          /* Trello board */
.achievement-badge     /* Badge styling */
.filtri-impara         /* Filtri articoli */
@media                 /* Responsive */
```

---

## 🌍 Valore Civico e Sociale

### **Educazione alla Salute**
✅ Promozione della consapevolezza su IMC, BMR, nutrizione
✅ Articoli educativi su prevenzione e screening
✅ Incoraggiamento di stili di vita attivi

### **Responsabilità Personale**
✅ Monitoraggio dati personali con tracciamento
✅ Gamification per motivare comportamenti salutari
✅ Sistema di obiettivi per responsabilità

### **Solidarietà e Comunità**
✅ Focus su benessere psico-fisico (salute mentale inclusa)
✅ Promozione di comunicazione e supporto
✅ Valori di prevenzione e consapevolezza collettiva

### **Cittadinanza Digitale**
✅ Privacy: dati salvati solo localmente
✅ Accessibilità: dark mode, contrast ratio, semantic HTML
✅ Consapevolezza: educazione sugli effetti della salute digitale

---

## 🔧 Specifiche Tecniche

### **Validazione**
- **Regex Nome:** `/^[A-Za-zÀ-ù]{1}[a-zà-ù\s]{1,}$/` (maiuscola iniziale, solo lettere)
- **Validazione Età:** 1-120 anni
- **Validazione Altezza:** 50-250 cm
- **Validazione Peso:** 20-300 kg

### **Formule Matematiche**
**IMC:** `peso(kg) / (altezza(m)²)`
**BMR (Harris-Benedict):**
- Uomo: `88.362 + (13.397×peso) + (4.799×altezza) - (5.677×età)`
- Donna: `447.593 + (9.247×peso) + (3.098×altezza) - (4.330×età)`
**TDEE:** `BMR × Fattore Attività`

### **Performance**
- Lazy loading immagini (loading="lazy")
- CSS variables per temi dinamici
- localStorage per persistenza
- Nessuna dipendenza esterna
- **Dimensioni totali:** ~2000 linee di codice

### **Browser Support**
- ✅ Chrome/Edge 88+
- ✅ Firefox 87+
- ✅ Safari 14+
- ✅ Mobile browsers moderni

---

## 📸 Features Highlight

### **Calcolo IMC con Consigli Intelligenti**
```
Input: Mario, 30 anni, 175cm, 70kg
Output:
  - IMC: 22.9
  - Categoria: Normopeso
  - Consiglio: "Mantieni il tuo stile di vita"
  - Esercizio: "Cardio + Forza (45 min, 3-4x/settimana)"
```

### **Analytics Dashboard**
```
Statistiche automatiche:
  - IMC Medio: 22.5
  - IMC Minimo: 21.0
  - IMC Massimo: 24.0
  - Variazione Peso: -2 kg
  - Profilo: "Sei sulla giusta strada! 📉"
```

### **Gamification System**
```
Achievement sbloccati:
  🎯 Primo Passo (50pt)
  📈 Trend Watcher (100pt)
  ⚡ Ogni Giorno (75pt)
  ⏱️ Timer Master (150pt)
  
  Totale Punti: 375 🏆
```

---

## 📚 Articoli Educativi (12 Totali)

**Nutrizione:**
1. 🥗 Alimentazione Consapevole
2. 💧 L'Importanza dell'Idratazione
3. 🥑 Grassi Salutari

**Esercizio:**
4. 💪 Iniziare una Routine Fitness
5. 🏃 Esercizio Aerobico e Anarobico
6. 🧘 Lo Stretching e la Flessibilità

**Salute Mentale:**
7. 🧠 Meditazione e Consapevolezza
8. 😴 Il Sonno, il Pilastro del Benessere
9. 💬 L'Importanza della Comunicazione

**Prevenzione:**
10. 🩺 Check-up Regolari
11. 🚭 Prevenzione dalle Malattie
12. 🏥 Educazione Sanitaria

---

## 🎨 Design & UX

### **Palette Colori**
- **Primario:** Arancione (#FF6D29)
- **Secondario:** Marrone (#453027)
- **Accent Light:** Arancione chiaro (#FF8A4D)
- **Testo:** Grigio scuro/chiaro (tema adattivo)

### **Tipografia**
- **Titoli:** Georgia (serif, elegante)
- **Corpo:** Segoe UI (sans-serif, leggibile)

### **Animazioni**
- `fadeInUp` - Elementi entry
- `slideIn` - Risultati e card
- `pulse` - Timer display
- `glow` - Achievement unlock
- Transizioni smooth su hover

### **Responsive Breakpoints**
- Mobile: < 650px
- Tablet: 650px - 1000px
- Desktop: > 1000px

---

## 🚀 Future Features (Backlog)

- [ ] API esterna per ricette salutari
- [ ] Drag & drop migliorato nel Trello
- [ ] 20+ articoli educativi per categoria
- [ ] PWA (offline mode)
- [ ] Esportazione dati PDF/CSV
- [ ] Notifiche push browser
- [ ] Pagina "Chi Siamo" con mission civica
- [ ] Integrazione social media

---

## 📄 Licenza

Questo progetto è creato per scopi educativi e di sensibilizzazione civica.

---

## ✍️ Credits

**Progetto:** Benessere Attivo - Educazione alla Salute  
**Sviluppatore:** [Il Tuo Nome]  
**Anno:** 2026  
**Tecnologie:** HTML5, CSS3, JavaScript (vanilla)  
**Tema:** Educazione Civica - Salute e Benessere

### **Risorse Utilizzate**
- Immagini: Unsplash (creative commons)
- Formule: Harris-Benedict (metabolismo)
- Ispirazione: WHO (World Health Organization)

---

## 📞 Supporto & Feedback

Per domande o suggerimenti sul progetto:
- 📧 Email: [email]
- 💬 Social: [link social]
- 📋 Issues: [link repository]

---

**Grazie per aver scelto Benessere Attivo! Inizia il tuo percorso verso il benessere consapevole.** 🌿✨

